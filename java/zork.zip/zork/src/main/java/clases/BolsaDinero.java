package clases;

import excepciones.NegativeBalanceException;

/**
 * This class creates a money bag, necessary to buy in the store
 * @author Grupo 4 Leidy
 * @version 1.1
 * @since 1.0 
 */
public class BolsaDinero extends ElementoPosicionado{
	//Private variables
	private byte saldo;
	//Constructor
	public BolsaDinero(byte[] pos, int saldo) throws NegativeBalanceException {
		super(pos);
		setSaldo(saldo);
	}
	
	//Getters and setters
	
	public byte getSaldo() {
		return saldo;
	}

	//Exceptions: In the event that the balance is lower.
	public void setSaldo(int saldo) throws NegativeBalanceException{
		if(saldo < 0){
			//Message that says you have no money 
			throw new NegativeBalanceException("No es posible crear una bolsa con saldo negativo.");
		}else{
			this.saldo = (byte)saldo;
		}
	}
	
	/*
	 * Overwrite the item to be able to add the balance in this case saldo.
	 * */
	@Override
	 public String toString() {
		String result = "Has encontrado una bolsa de dinero con "+ this.saldo + " monedas";
		return result;
	}
}
