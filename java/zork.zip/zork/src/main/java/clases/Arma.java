package clases;

import enums.NivelArma;
import enums.TipoArma;

/**
 * This class creates the game's weapons relative to its Kind and Level
 * @author Sonia Pujol
 * @version 1.0
 */
public class Arma {
	
	//Private variables
	private String nombre;
	private String descripcion;
	private byte precio;
	private byte puntosAtaque;
	private byte puntosDefensa;
	

	//Constructor
	public Arma(TipoArma tipoArma, NivelArma nivelArma) {
		inicializarArma(tipoArma, nivelArma);
	}
		
	//Getters (setters are not necessary. Variables' values will not change)
	public String getNombre() {return this.nombre;}
	public byte getPrecio() {return this.precio;}	
	public byte getPuntosAtaque() {return this.puntosAtaque;}	
	public byte getPuntosDefensa() {return this.puntosDefensa;}	
	
	
	/**
	 * This function sets values to each element relative to the variables requested in the constructor.
	 * @param tipoArma
	 * @param nivelArma
	 */
	private void inicializarArma(TipoArma tipoArma, NivelArma nivelArma) {
		
		TipoArma tipo = tipoArma;
		NivelArma nivel = nivelArma;
		
		this.precio = nivel.getPrecio();
	
		
		switch (nivel) {
			case BASICA:
				
				if (tipo == TipoArma.ESPADA ) {
					this.nombre= "ESPADA CUTRE";
					this.descripcion = "Espada de madera, no corta pero aturde al enemigo si le das bi�n.";
					this.puntosAtaque = nivel.getPuntos();
					this.puntosDefensa = 0;
				} else {
					this.nombre= "ESCUDO CHAPUCERO";
					this.descripcion = "Escudo de madera aglomerada de baja calidad, te puede salvar de algun ataque pero no le pidas demasiado.";
					this.puntosAtaque = 0;
					this.puntosDefensa = nivel.getPuntos();
				}
				
				break;
			case NORMAL:
				
				if (tipo == TipoArma.ESPADA ) {
					this.nombre= "ESPADA COM�N";
					this.descripcion = "Espada de hierro con hoja de doble filo, con esta ya podr�s matar algo.";
					this.puntosAtaque = nivel.getPuntos();
					this.puntosDefensa = 0;
				} else {
					this.nombre= "ESCUDO VIK";
					this.descripcion = "Escudo de madera, rollo vikingos. Seguro que sabes de que te hablo.";
					this.puntosAtaque = 0;
					this.puntosDefensa = nivel.getPuntos();
				}
				
				break;
			case EXTRA:
				
				if (tipo == TipoArma.ESPADA ) {
					this.nombre= "ESPADA CORTA-PIZZAS";
					this.descripcion = "No te dejes enga�ar por su nombre, �sta es la m�s mortal.";
					this.puntosAtaque = nivel.getPuntos();
					this.puntosDefensa = 0;
				} else {
					this.nombre= "ESCUDO ANTI-PI�A";
					this.descripcion = "Anti pi�azos... Nada m�s que decir.";
					this.puntosAtaque = 0;
					this.puntosDefensa = nivel.getPuntos();
				}
				
				break;
		}
	}
	
	
	/**
	 * This function overrides toString() to show the characteristics of weapon
	 */
	@Override
	public String toString() {		
		return 	this.nombre + ": " + this.descripcion + " \n" +
				(this.puntosAtaque!=0?  "\t" + "Ataque: +" + this.puntosAtaque + " \n" : "" ) +
				(this.puntosDefensa!=0? "\t" + "Defensa: +" + this.puntosDefensa + " \n" : "" ) +
				"\t" + "Precio: "+ this.precio + "�" + " \n";		
	}

}

