package clases;
/**
 * Define each one of the map squares
 * @author Raquel Malo
 * @version 3.1
 * @since 1.0
 *
 */
public class Celda {
	
	private String descripcion;
	private char[] posibilidades; //Possible movements
	private ElementoPosicionado elemento;
	
	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	public char[] getPosibilidades() {
		return posibilidades;
	}
	
	public void setPosibilidades(char[] posibilidades) {
		this.posibilidades = posibilidades;
	}

	public ElementoPosicionado getElemento() {
		return elemento;
	}

	public void setElemento(ElementoPosicionado elemento) {
		this.elemento = elemento;
	}

	//Constructor
	public Celda(String descripcion) {
		this.descripcion = descripcion;
	}	
	
}
