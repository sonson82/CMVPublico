package clases;

import java.util.ArrayList;
import java.util.Random;
import excepciones.NullNameException;
import excepciones.NullLetraException;
import java.util.Scanner;

import enums.TipoArma;

public class Protagonista extends Personaje {
	private ArrayList<Arma> armasDisponibles;
	private byte saldo;
	private byte ataqueActual;
	private byte defensaActual;
	
	public static void escogerArma(Scanner sc,Arma armasDisponibles){
		String tec;
		byte armaEscogida = 0;
		byte escudoEscogido = 0;
		try {
		System.out.println("Que arma quieres, escudos o espadas?");
		tec= sc.nextLine().toUpperCase();
		TipoArma tipo = null;
		switch (tec){
			 case"ESPADAS":
			 			if(tipo == TipoArma.ESPADA) {
			 				System.out.println("Estos son los tipos de espadas que tienes: "+ tipo);
			 				armaEscogida = sc.nextByte();
			 				System.out.println("La espada escogida es: " + armaEscogida);
			 			}
			 case "ESCUDOS":
			 if(tipo == TipoArma.ESCUDO) {
	 				System.out.println("Estos son los tipos de escudos que tienes: "+ tipo);
	 				escudoEscogido = sc.nextByte();
	 				System.out.println("El escudo escogido es: " + escudoEscogido);
	 			}
			 break;
			 default:
			 System.out.println("No es la respuesta correcta...");
			 tec= null;
			 break;
		 }
		 while (tec==null);
		}catch(Exception e){
			System.out.println("Debe ingresar obligatoriamente letras");
		}

	}
	/**
	 * @param posicion
	 * @param nombre
	 * @param descripcion
	 * @param ataque
	 * @param defensa
	 * @throws NullNameException
	 */
	
	public Protagonista(byte[] posicion, String nombre, String descripcion, int ataque, int defensa) throws NullNameException {
		super(posicion, nombre, descripcion, ataque, defensa);
		this.saldo = 0;		
		this.ataqueActual = (byte)ataque;
		this.defensaActual = (byte)defensa;
		armasDisponibles = new ArrayList<Arma>();
	}


	public ArrayList<Arma> getArmasDisponibles() {
		return armasDisponibles;
	}


	public void setArmasDisponibles(Arma armasDisponibles) {
		this.armasDisponibles.add(armasDisponibles);
	}


	public byte getSaldo() {
		return saldo;
	}


	public void setSaldo(byte saldo) {
		this.saldo = saldo;
	}


	public byte getAtaqueActual( ) {
		return this.ataqueActual;
	}


	public void setAtaqueActual(ArrayList<Arma> armasUsadas) {
		this.ataqueActual = this.getAtaque();
		for (int i = 0; i < armasUsadas.size(); i++) {
			this.defensaActual += armasUsadas.get(i).getPuntosAtaque();
		}
		
	}


	public byte getDefensaActual() {
		return defensaActual;
	}


	public void setDefensaActual(ArrayList<Arma> armasUsadas) {
		this.defensaActual = this.getDefensa();
		for (int i = 0; i < armasUsadas.size(); i++) {
			this.defensaActual += armasUsadas.get(i).getPuntosDefensa();
		}
	}
	
	public ArrayList<Arma> elegirArmas(){
		return this.armasDisponibles; //by default
		// TODO @Martina
	}

	/**
	 * Result of the battle
	 * @param p Your adversary
	 * @return result 0: both survive, 1:you die and the enemy survives, 2:enemy dies and you survive, 3:both die
	 */
	public byte combate(Personaje p) {
		byte result = 0;
		boolean protaDied = false;
		boolean enemyDied = false;
		Random rand = new Random();		
		byte finalAtackP = (byte) rand.nextInt(this.getAtaqueActual()+1); 
		byte finalDefendP = (byte) rand.nextInt(this.getDefensaActual()+1);
		byte finalAtackE = (byte) rand.nextInt(p.getAtaque()+1);
		byte finalDefendE = (byte) rand.nextInt(p.getDefensa()+1);
		if (finalAtackP > finalDefendE) {enemyDied = true;}
		if (finalAtackE > finalDefendP) {protaDied = true;}
		
		if(protaDied & enemyDied) {
			result = (byte) 3;
		}
		if(!protaDied & enemyDied) {
			result = (byte) 2;
		}
		if(protaDied & !enemyDied) {
			result = (byte) 1;
		}
		if(!protaDied & !enemyDied) {
			result = (byte) 0;
		}
		
		return result;
	}
	
	@Override
	public String toString() {
		return "Protagonista [armasDisponibles=" + armasDisponibles + ", saldo=" + saldo + ", ataqueActual="
				+ ataqueActual + ", defensaActual=" + defensaActual + ", elegirArmas()=" + elegirArmas()
				+ ", getArmasDisponibles()=" + getArmasDisponibles() + ", getAtaqueActual()=" + getAtaqueActual()
				+ ", getDefensaActual()=" + getDefensaActual() + ", getSaldo()=" + getSaldo() + "]";
	}

}