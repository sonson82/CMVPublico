package clases;

import excepciones.NullNameException;

/**
 * Protagonist and enemy superclass, with all characteristics from the personages 
 * @author Raquel Malo
 * @version 2.1
 * @since 1.0
 *
 */
public abstract class Personaje extends ElementoPosicionado {	
	private String nombre;
	private String descripcion;
	private byte ataque;
	private byte defensa;
	
	public Personaje(byte[] posicion, String nombre, String descripcion, int ataque, int defensa) throws NullNameException {
		super(posicion);
		setNombre(nombre);
		setDescripcion(descripcion);
		setAtaque((byte) ataque);
		setDefensa((byte) defensa);
	}
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) throws NullNameException {
		if (nombre==null || nombre.isBlank() || nombre.isEmpty()) {
			throw new NullNameException("No puede estar el nombre del personaje vac�o");
		}
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public byte getAtaque() {
		return ataque;
	}

	public void setAtaque(byte ataque) {
		this.ataque = ataque;
	}

	public byte getDefensa() {
		return defensa;
	}

	public void setDefensa(byte defensa) {
		this.defensa = defensa;
	}

}
