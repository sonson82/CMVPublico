package clases;

import java.util.Random;

import enums.TipoEnemigo;
import excepciones.NegativeBalanceException;
import excepciones.NullNameException;

/**
 * Create all Zork world
 * 
 * @author Raquel Malo
 * @version 1.0
 * @since 1.0
 */
public class Mapa {

	private Celda[][] celdas;

	public Celda[][] getCeldas() {
		return celdas;
	}

	public void setCeldas(Celda[][] celdas) {
		this.celdas = celdas;
	}

	public Mapa() {
		Celda[][] mapa = new Celda[4][4];		
		createDescriptions(mapa);
		setPossibleMovements(mapa);		
		inicializarPartida(mapa);
		 
		setCeldas(mapa);
	}
		
	/**
	 * Initialization of the description to each cell
	 * @param mapa Map of the world
	 */
	private void createDescriptions(Celda[][] mapa) {
		
		mapa[0][0]= new Celda ("Est�s al borde de un alcantilado al noroeste de la isla. S�lo ves mar y verde.");
		mapa[0][0]= new Celda ("Est�s al borde de un alcantilado al noroeste de la isla. S�lo ves mar y verde.");
		mapa[0][1]= new Celda ("Te encuentras a orillas de un alcantilado que ocupa toda orilla norte de la isla.");
		mapa[0][2]= new Celda ("Te encuentras a orillas de un alcantilado que ocupa toda orilla norte de la isla y al sur hay un peque�o monte cubierto de palmeras.");
		mapa[0][3]= new Celda ("Has llegado al extremo noreste de la isla. Al sur del alcantilado hay un bosque de palmeras.");
		mapa[1][0]= new Celda ("Est�s en una pradera verde, pero parece que que adivinas un precipio en el horizonte y a la izquierda solo hay mar y rocas.");
		mapa[1][1]= new Celda ("Todo es verde a tu alrededor pero notas que asciendes hacia la derecha donde se encuentra la entrada a un bosque de palmeras.");
		mapa[1][2]= new Celda ("Est�s en el punto m�s alto de la isla aunque los �rboles tapan las vistas. Junto donde te encuentras nace un r�o que desemboca al sur.");
		mapa[1][3]= new Celda ("Est�s dentro del bosque de palmeras junto al borde este de la isla. Al sur se divisa un claro.");
		mapa[2][0]= new Celda ("Est�s en una pradera verde, no se ve nada al horizonte y a la izquierda solo hay mar y rocas.");
		mapa[2][1]= new Celda ("Empieza a haber �rboles y ascender hacia un peque�o monte al este. Al sur se adivina la playa.");
		mapa[2][2]= new Celda ("Est�s ascendiendo un monte y te encuentras con un peque�o riachulo que nace de la cima.");
		mapa[2][3]= new Celda ("Clarea el bosque y te das cuenta que has llegado al extremo oriental de la isla, junto a un embarcadero.");
		mapa[3][0]= new Celda ("Has llegado al extremo suroccidental de la isla. Hacia el norte la orilla se torna rocosa y al este se extiende una playa de arena blanca.");
		mapa[3][1]= new Celda ("Te encuentras en una preciosa y peque�a cala con casas de pescadores.");
		mapa[3][2]= new Celda ("Has llegado a la desembocadura de un r�o que parte en dos la playa de la isla, junto a la cual se ubica un peque�o pueblo pesquero.");
		mapa[3][3]= new Celda ("Has llegado al estremo suroriental. Ah� termina la playa y el pueblo que se extiende a la izquierda. Al norte ves un embarcadero.");			
	}
	
	
	/**
	 * Set the movement possibilities
	 * @param mapa Map of the world
	 */
	private void setPossibleMovements(Celda[][] mapa) {
		char[] all = { 'N', 'S', 'E', 'O' };		
		char[] seo = { 'S', 'E', 'O' };
		char[] nse = { 'N', 'S', 'E' };
		char[] nso = { 'N', 'S', 'O' };
		char[] neo = { 'N', 'E', 'O' };
		char[] se = { 'S', 'E' };
		char[] ne = { 'N', 'E' };
		char[] so = { 'S', 'O' };
		char[] no = { 'N', 'O' };
	    
	    for (int i = 0; i < mapa.length; i++) {
			for (int j = 0; j < mapa[i].length; j++) {
				if (i==0) {					
					if(j==0) {
						mapa[i][j].setPosibilidades(se);
					} else if(j==mapa.length-1) {
						mapa[i][j].setPosibilidades(so);
					} else {
						mapa[i][j].setPosibilidades(seo);
					}
				}else if (i == mapa.length-1) {
					if(j==0) {
						mapa[i][j].setPosibilidades(ne);
					} else if(j==mapa.length-1) {
						mapa[i][j].setPosibilidades(no);
					} else {
						mapa[i][j].setPosibilidades(neo);
					}
				}else {
					if(j==0) {
						mapa[i][j].setPosibilidades(nse);
					} else if(j==mapa.length-1) {
						mapa[i][j].setPosibilidades(nso);
					} else {
						mapa[i][j].setPosibilidades(all);
					}
				}
			}
		}
	}
    
	/**
	 * Fist set occupied to false and element to null for each cell, and second create all the game fixed elements
	 * @param mapa Array of cells
	 * @throws NegativeBalanceException 
	 * @throws NullNameException 
	 */
	public void inicializarPartida(Celda[][] mapa) {			
		
		for (int i = 0; i < mapa.length; i++) {
			for (int j = 0; j < mapa[i].length; j++) {
				mapa[i][j].setElemento(null); //Elemento ya nulo si iniciamos juego por 1�vez pero no si empezamos nueva partida antes de salir.				
			}
		}		
				
		Enemigo pear, banana, hamster, boss;
		try {
			pear = new Enemigo(randomPosition(mapa), "Pera con espada", "Quiz�s no sea el m�s temible de los enemigos, ni el m�s duro, pero no la subestimes.", 2, 1, TipoEnemigo.COMUN);
			mapa[pear.getPosicion()[0]][pear.getPosicion()[1]].setElemento(pear);
			banana = new Enemigo(randomPosition(mapa), "Banana con ca��n", "Ojo con este pl�tano que se las gasta a zambombazos.", 6, 2, TipoEnemigo.COMUN);
			mapa[banana.getPosicion()[0]][banana.getPosicion()[1]].setElemento(banana);
			hamster = new Enemigo(randomPosition(mapa), "Hamster con cuchillo", "Peque�o pero mat�n. No es muy fuerte pero s� muy escurridizo.", 1, 6, TipoEnemigo.COMUN);
			mapa[hamster.getPosicion()[0]][hamster.getPosicion()[1]].setElemento(hamster);
			boss = new Enemigo(randomPosition(mapa), "Pizza con pi�a", "�Que no se te atrangante! porque esta pizza tan indigesta va a por todas y resulta dura de roer; pero si la vences, ganas la partida.", 8, 8, TipoEnemigo.BOSS);
			mapa[boss.getPosicion()[0]][boss.getPosicion()[1]].setElemento(boss);			
		} catch (NullNameException nne) {
			System.out.println("Error del sistema: "+nne.getMessage());
			System.exit(1);
		}	
		Tienda shop = new Tienda(randomPosition(mapa));
		mapa[shop.getPosicion()[0]][shop.getPosicion()[1]].setElemento(shop);
		BolsaDinero bag1, bag2, bag3;
		try {
			bag1 = new BolsaDinero(randomPosition(mapa), 10);
			mapa[bag1.getPosicion()[0]][bag1.getPosicion()[1]].setElemento(bag1);
			bag2 = new BolsaDinero(randomPosition(mapa), 20);
			mapa[bag2.getPosicion()[0]][bag2.getPosicion()[1]].setElemento(bag2);
			bag3 = new BolsaDinero(randomPosition(mapa), 20);				
			mapa[bag3.getPosicion()[0]][bag3.getPosicion()[1]].setElemento(bag3);
		} catch (NegativeBalanceException nbe) {
			System.out.println("Error del sistema: "+nbe.getMessage());
			System.exit(1);
		}		
	}		 
	
	/**
	 * Recursive function that generates a random position
	 * @return Position(x,y) in the map of the world Zork
	 */
	private byte[] randomPosition(Celda[][] mapa) {
		Random rand = new Random();
		byte posX = (byte) rand.nextInt(4);
		byte posY = (byte) rand.nextInt(4);
		byte[] position = {posX, posY};	
		
		while (mapa[position[0]][position[1]].getElemento() != null) { 
			position = randomPosition(mapa); //Until a free position
		} 
		
		return position;		
	}			
	
}