package clases;

import enums.TipoEnemigo;
import excepciones.NullNameException;

/**
 * Property and constructor of the game enemies
 * @author Raquel Malo
 * @version 2.0
 * @since 1.0
 *
 */
public class Enemigo extends Personaje {
	private TipoEnemigo tipoEnemigo;
	
	public TipoEnemigo getTipoEnemigo() {
		return tipoEnemigo;
	}

	public void setTipoEnemigo(TipoEnemigo tipoEnemigo) {
		this.tipoEnemigo = tipoEnemigo;
	}

	public Enemigo(byte[] pos, String nombre, String descripcion, int ataque, int defensa, TipoEnemigo tipo) throws NullNameException{
		super(pos, nombre, descripcion, ataque, defensa);
		this.tipoEnemigo = tipo;
	}
	
	@Override
	public String toString() {
		return this.getNombre()+"\n"+
				this.getDescripcion() + "\n"+
				"Ataque: "+this.getAtaque()+
				"\tDefensa: "+this.getDefensa()+"\n";
	}
}
