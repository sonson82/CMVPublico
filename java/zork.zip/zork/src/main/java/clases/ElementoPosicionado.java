package clases;


/**
 * Superclass from all game elements with position inherit
 * @author Raquel Malo
 * @version 2.0
 * @since 1.0
 *
 */
public abstract class ElementoPosicionado {

	private byte[] posicion;
	
	public byte[] getPosicion() {
		return posicion;
	}

	public void setPosicion(byte[] posicion) {
		this.posicion = posicion;
	}
	
	public ElementoPosicionado(byte[] pos) {		
		this.posicion = pos;
	}

}
