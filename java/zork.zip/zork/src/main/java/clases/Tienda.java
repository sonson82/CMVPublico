package clases;

import java.util.ArrayList;

import enums.NivelArma;
import enums.TipoArma;


/**
 * This class creates an array with the game's weapons available in the store
 * @author Sonia Pujol
 * @version 1.0
 */
public class Tienda extends ElementoPosicionado {

	//Private variables
	private ArrayList<Arma> armasEnVenta = new ArrayList<Arma>();
	
	//Constructor
	public Tienda(byte[] posicion) {
		super(posicion);
		getWeaponList();
	}

	//Getter and setter
	public  ArrayList<Arma>  getArmasEnVenta() {return this.armasEnVenta;}	
	public void setArmasEnVenta(ArrayList<Arma> armasEnVenta) {
		this.armasEnVenta = armasEnVenta;
	}	
	
	
	/**
	 * This function get all weapons' possibilities and set them into an array.
	 */
	private void getWeaponList() {
		for (TipoArma tipo : TipoArma.values()) {
			for (NivelArma nivel : NivelArma.values()) {
				this.armasEnVenta.add(new Arma(tipo, nivel));
	        }
        }
	}
	
	/**
	 * This function overrides toString() to show the list of all weapons into the array
	 */
	@Override
	 public String toString() {
		
		String result = "";
		
		if (this.armasEnVenta.size() == 0) {
			result += "No hay armas disponibles en la tienda... ¡las has comprado todas! " + "\n";	
			
		} else {
			result += "Hay " + this.armasEnVenta.size() + " armas disponibles en la tienda: " + "\n" + "\n";	
			for ( byte j=0; j<this.armasEnVenta.size() ; j++ ) {		
				result  += "Arma " + (j+1) + ": " + this.armasEnVenta.get(j).toString() + "\n";	
			}
		}
		
		return result;
	}
	
}

