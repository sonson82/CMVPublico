package enums;

/**
 * This enum defines Weapon's level and its price and points
 * @author S�nia Pujol
 */
public enum NivelArma {
	BASICA((byte) 10,(byte)  2),
	NORMAL((byte) 15, (byte) 4),
	EXTRA((byte) 30, (byte) 7);
	
	//Private variables
	private byte precio;
	private byte puntos;
	
	//Constructor
	private NivelArma (byte precio, byte puntos) {
		this.precio = precio;
		this.puntos = puntos;
	}
	
	//Getters
	public byte getPrecio(){ return precio; }
	public byte getPuntos(){ return puntos; }

	
	
}
