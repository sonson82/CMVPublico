package enums;

/**
 * This enum defines Weapon's types
 * @author S�nia Pujol
 */
public enum TipoArma {
	ESPADA,
	ESCUDO;
}
