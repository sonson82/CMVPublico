package enums;

public enum TipoEnemigo {
	COMUN,
	BOSS	
}
