package principal;

import java.util.Random;
import java.util.Scanner;

/**
 * This class content other necessary functions functions for the program
 * @author Grupo 4 - MVC Accenture
 * @version 1.0
 */
public class FuncionesSecundarias {
	
	
	/**
	 * This recursive function gets from the keyboard a byte number and returns it.
	 * @author Sonia Pujol
	 * @param Scanner sc It works with java.util.Scanner
	 * @param byte min Minimum of the asked number
	 * @param byte max Maximum of the asked number
	 * @return byte  It retrurns a byte number.
	 */
	public static byte getByteFromKeyboard(Scanner sc, byte max) {
		byte num;
		
		try {
			System.out.println("Entre 1 y " + max + ":");
			num = Byte.parseByte(sc.nextLine());
			
			if ((num >= 1) && (num <= max)) {
				return num;
			} else {
				System.out.println("Has indicado un n�mero incorrecto." + "\n");
				return getByteFromKeyboard(sc, max);
			}
			
		} catch (NumberFormatException nfe) {
			System.out.println("Necesitamos un n�mero."+ "\n");
			return getByteFromKeyboard(sc, max);
		}
	}
	
	/**
	 * This function gets a random number with maximun and minimum
	 * @author S�nia Pujol
	 * @param int min This is the minimum number to get the random number.
	 * @param int max This is the maximum number to get the random number.
	 * @return byte It returns a byte random number
	 */
	public static byte getRandomNumber(int min, int max) {
		Random random = new Random();
		return (byte) (random.nextInt(max - min) + min + 1); //+1 for including the max between the possible random numbers
	}
	
	
}
