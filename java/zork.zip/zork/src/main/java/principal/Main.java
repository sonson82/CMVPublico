package principal;

import clases.Tienda;
import clases.BolsaDinero;
import clases.Celda;
import clases.ElementoPosicionado;
import clases.Protagonista;
import clases.Enemigo;
import clases.Mapa;
import excepciones.NullNameException;
import excepciones.OffMapPositionException;

import java.util.Scanner;
/**
 * This is the principal class in this project
 * 
 * @author GRUPO 04
 * @version 1.2
 * @since 1.0
 */
public class Main {
	/**
	 * This function runs the game
	 * @author Sonia Pujol
	 * @param args
	 * @throws OffMapPositionException 
	 */
	public static void main(String[] args) {
		
		//Initialize Scanner
		Scanner sc = new Scanner(System.in);
		
		//And the game's options for continue or not
		boolean salirDelJuego = false;
		boolean partida = true;
		//Instance of map		
		Mapa mapa = new Mapa();	 		
		
		System.out.println("�BIENVENID@ A ZORK!");	
		
		do {	
			//We store variables for database
			//LocalDateTime hora_inicio = LocalDateTime.now();
			
			int cambios_casilla = 0;			  
			  
			java.util.Date date = new java.util.Date(); 
			java.sql.Timestamp hora_inicio = new java.sql.Timestamp(date.getTime());		
			
			//Initialize the initial random position of the principal personage
			byte [] posicionActual = {FuncionesSecundarias.getRandomNumber(0, 3), FuncionesSecundarias.getRandomNumber(0, 3)};
			Protagonista protagonista = null;
			String name = null;
			
			do {
				System.out.println("\n�C�mo te llamas?");	
				name = sc.nextLine();
				//Instance of the principal personage			
				try {
					protagonista = new Protagonista(posicionActual, name, "Eres un/a intr�pid@ guerrer@ isle�@ de Ocean�a, explorando mundos nuevos y desconocidos repletos de los personajes m�s descabellados.", 3, 3);
				} catch (NullNameException nne) {
					System.out.println(nne.getMessage());
				}
			} while(protagonista == null);	
			
			//Esto puede ir en el toString de Protagonista junto con la descripci�n de personaje despu�s del nombre.
			System.out.println("\nHola "+protagonista.getNombre());

			//We will show gamer's data from Database
			DatabaseConnectFunctions.getFromDatabase(name);
			
			System.out.println("Empiezas la partida con "+ protagonista.getSaldo() + " monedas, y con " + protagonista.getAtaque() + " puntos de ataque y " + protagonista.getDefensa() + " de defensa.\n");	
			System.out.println("�Disfruta de la partida!" + "\n");	

			//Get array celdas
			Celda [][] celdas =  mapa.getCeldas();
			Celda celdaActual = celdas[posicionActual[0]][posicionActual[1]];
						
			//while the game is playing
			do {
				//we say to the player the actual description of the place
				System.out.println(celdaActual.getDescripcion());
				
				//If there is something to play with
				if(celdaActual.getElemento() != null) {
					
					ElementoPosicionado tipoElemento = celdaActual.getElemento();
					
					if(tipoElemento instanceof Tienda) {	
						//we call comprarArma;
						Funciones.comprarArma(sc, (Tienda) tipoElemento, protagonista); //comprarArma(Scanner sc, Tienda tienda, Protagonista protagonista)
						partida = true;
						
					} else if (tipoElemento instanceof BolsaDinero) {
						//we call recogerBolsa;
						Funciones.recogerBolsa((BolsaDinero) tipoElemento, protagonista, celdaActual);
						partida = true;
						
					} else if(tipoElemento instanceof Enemigo) {
						//we call  lucha; Almacenamos resultado en partida
						partida = Funciones.luchaEntrePersonajes((Enemigo) tipoElemento, protagonista, partida, celdaActual);
					}
					
					//If the game is going on
					if(partida == true) {
						
						//We ask for the direction to go
						cambios_casilla = Funciones.desplazamientoProtagonista(sc, celdaActual, posicionActual, cambios_casilla);

						//And place the player there
						celdaActual = celdas[posicionActual[0]][posicionActual[1]];
					}
					
				//If there's nothing
				} else {
					System.out.println("No tienes mucho que hacer por aqu�...");
					
					//We ask for the direction to go
					cambios_casilla = Funciones.desplazamientoProtagonista(sc, celdaActual, posicionActual, cambios_casilla);
					
					//And place the player there
					celdaActual = celdas[posicionActual[0]][posicionActual[1]];
				}
				
			} while (partida); //False: fin de partida
			
			String res = null;
			
			
			//On games over
			do {
				// We store elements on database:			
				DatabaseConnectFunctions.setToDatabase(name, hora_inicio, cambios_casilla);
						
				//we ask for another game
				System.out.println("�Quieres jugar otra vez, " + name + "?  (Y/N)");
				res = sc.nextLine().toUpperCase();
				
				switch (res) {
					case "Y": 
						System.out.println("���Vamos!!!!");
						salirDelJuego = false;
						mapa.inicializarPartida(celdas);
						break;
					case "N":
						System.out.println("De acuerdo, no insistir�... �hasta la pr�xima!");
						salirDelJuego = true;
						break;
					default:
						System.out.println("No he entendido tu respuesta...");
						res = null;
						break;
				}
				
			} while (res == null); 

		} while (!salirDelJuego);
		
		//Cerrar Scanner
		sc.close();
		}

}
