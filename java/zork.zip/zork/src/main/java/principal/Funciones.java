package principal;

import java.util.ArrayList;
import java.util.Scanner;

import clases.Arma;
import clases.BolsaDinero;
import clases.Celda;
import clases.Enemigo;
import clases.Protagonista;
import clases.Tienda;
import enums.TipoEnemigo;

import excepciones.OffMapPositionException;

/**Class with the base functions to the four principal game actions 
 * @author grupo4 MVC-Accenture
 * @version 3.0
 * @since 1.0
 */
public class Funciones {
	
	/**
	 * This function let buy a weapon if there are weapons and money and change the necessary variables
	 * @author Sonia Pujol
	 * @param Scanner sc It works with java.util.Scanner
	 * @param Celda celda To get the posibilities to move;
	 * @param  byte [] posicionActual It gets the actual position and change it after move.
	 */
	public static int desplazamientoProtagonista(Scanner sc, Celda celda, byte [] posicionActual, int cambios_casilla){ 
		
		byte [] nuevaPosicion = posicionActual;
		boolean isPosible = false;
		char [] posibilidades = celda.getPosibilidades();
		String direccion = null;
		
		
		//Reposicionar seg�n la respuesta
		do {
			escribirMovimientoPosible(posibilidades);
			direccion = sc.nextLine().toUpperCase();
				
			do {
				switch (direccion) {
				
				case "N":
					for (byte i = 0; i < posibilidades.length; i++) {
						if(posibilidades[i] == 'N') {
							nuevaPosicion[0] = (byte) (posicionActual[0]-1);
							isPosible = true;
							cambios_casilla += 1;
						};
					}
					
					break;
				case "S": 
					for (byte i = 0; i < posibilidades.length; i++) {
						if(posibilidades[i] == 'S') {
							nuevaPosicion[0] = (byte) (posicionActual[0]+1);
							isPosible = true;
							cambios_casilla += 1;
						};
					}
					
					break;
				case "O":
					for (byte i = 0; i < posibilidades.length; i++) {
						if(posibilidades[i] == 'O') {
							nuevaPosicion[1] = (byte) (posicionActual[1]-1);
							isPosible = true;
							cambios_casilla += 1;
						};
					}
					
					break;
				case "E":
					for (byte i = 0; i < posibilidades.length; i++) {
						if(posibilidades[i] == 'E') {
							nuevaPosicion[1] = (byte) (posicionActual[1]+1);
							isPosible = true;
							cambios_casilla += 1;
						};
					}
					
					break;
				default:
					System.out.println("Ind�canos una direcci�n correcta...");
					direccion = null;
					break;
			}
				
				if ((isPosible == false) && (direccion != null)) {System.out.println("No puedes seguir por ah�... Te lo repito:");}
				
		
				
			} while (isPosible = false);
			
			//En caso de haber calculado mal las opciones o modificaciones en la posicion del jugador, 
			//capturaremos la excepci�n, dejaremos al jugador en la casilla actual y solicitaremos el movimiento nuevamente.
			if((nuevaPosicion[0]<0) || (nuevaPosicion[0]>3) || (nuevaPosicion[1]<0) || (nuevaPosicion[1]>3)) {
				try {
					
					Exception offMap = new OffMapPositionException("Uff... �Parece que te has ca�do al agua! Culpa nuestra... �Volvemos atr�s!");
					throw offMap;
					
				}catch (Exception offMap){
					offMap.printStackTrace();
					nuevaPosicion = posicionActual;
				}	
			}
			
		} while (direccion == null);
		
		return cambios_casilla;
	}
	
	
	/**
	 * This function says to gamer witch possibilities has to move on 
	 * @param posibilidades form each celda
	 */
	public static void escribirMovimientoPosible(char [] posibilidades) {
		
		//Solicitar direcci�n en funci�n de las posibilidades:
		String result = "�Hacia d�nde quieres ir?  ";
		
		for (byte i=0; i < posibilidades.length; i++) {
			
			switch (posibilidades[i]) {
			
				case 'N':
					result += "Norte(N)";
					break;
				case 'S': 
					result += "Sur(S)";
					break;
				case 'O':
					result += "Oeste(O)";
					break;
				case 'E':
					result += "Este(E)";
					break;
				default:
					result += "";
					break;
			
			}
			result += (i != posibilidades.length-1)? ", " : "." ;
		}
		System.out.println(result);
	}
	
	

	/**
	 * This function let buy a weapon if there are weapons and money and change the necessary variables
	 * @author S�nia Pujol
	 * @param Scanner sc It works with java.util.Scanner
	 * @param Tienda tienda It needs available weapons list from the store
	 * @param Protagonista protagonista It needs a main character to interact
	 */
	public static void comprarArma(Scanner sc, Tienda tienda, Protagonista protagonista) {
		System.out.println("�Has encontrado la Armer�a!");
		
		byte saldo = protagonista.getSaldo();
		ArrayList<Arma> armasEnVenta = tienda.getArmasEnVenta();
	
		//If there is no weapons in the store
		if(armasEnVenta.size() == 0) { 
		System.out.println("Pero, ya no nos quedan m�s armas. �Las tienes todas tu!");
		
		//If the main character has no enough money	
		} else if(saldo < 10) { 
			System.out.println("Pero... �No tienes saldo suficiente para comprar nada!" + "\n" + "�Ve a buscar m�s monedas y vuelve!");

		//If it has enough money and there are weapons in the store	
		} else { 
			String res = null;
			
			//Show character's money and store's list of available weapons
			System.out.println("Tienes " + saldo + " monedas.");
			System.out.println(tienda.toString());
			
			do {
				System.out.println("�Quieres comprar alguna arma? (Y/N)");
				res = sc.nextLine().toUpperCase();
				
				switch (res) {
				
					//If he wants to buy something
					case "Y": 		
						
						byte armaNum = 0;
						
						//Choose an affordable weapon
						do {	
							System.out.println("Indica el n�mero de arma elegida.");
							armaNum = FuncionesSecundarias.getByteFromKeyboard(sc, (byte) armasEnVenta.size());
							//Get chosen weapon from the arraylist
							Arma armaEscogida = armasEnVenta.get(armaNum-1);
							
							//If the character has enough money to buy it
							if (armaEscogida.getPrecio() <= saldo) { 
								
								System.out.println("\n" + "Has comprado: ");
								System.out.println(armaEscogida.toString());
								
								//Remove from store's list
								armasEnVenta.remove(armaNum - 1);
								tienda.setArmasEnVenta(armasEnVenta);

								
								//And CHANGE MAIN CHARACTER'S VARIABLES (saldo, arraylistArma y puntosAtaque/Defensa):
								//Set it to character's weapons list
								protagonista.setArmasDisponibles(armaEscogida);
								
								//Change main character's money
								saldo = (byte) (saldo - armaEscogida.getPrecio());
								protagonista.setSaldo(saldo);
								
								
								//This part of function has to go inside Protagonista's class.
								//Change main character's points
								/*Si hacemos la funci�n escoger arma de la clase Protagonista, esto no va aqu�, sin� all�... dependiendo de las armas seleccionadas.
								short points= 0;
								if (armaEscogida.getPuntosAtaque() != 0) {
									points = Protagonista.getAtaqueActual() + armaEscogida.getPuntosAtaque();
									protagonista.setAtaqueActual(points);
									System.out.println("�Ahora tienes " + points + " puntos de ataque! ");
									
								} else {
									points = Protagonista.getDefensaActual() + armaEscogida.getPuntosDefensa();
									protagonista.setDefensaActual(points);
									System.out.println("�Ahora tienes " + points + " puntos de defensa! ");
								}*/
								
								
								System.out.println("Te quedan: " + saldo + " monedas. " + armaEscogida.getPrecio() + " monedas menos que antes...");
								System.out.println("�Gracias por tu compra!");
								
							} else { 
								System.out.println("Lo siento... pero no tienes monedas suficientes para pagar " + armaEscogida.getNombre() + ".\n"  + "Prueba con otra m�s sencilla... ");
								armaNum = 0; 
							}
	
						} while(armaNum == 0);
						
						break;
						
					// If he doesn't wants to buy something	s
					case "N": 
						
						System.out.println("Gracias de todas formas, espero que tengas suficiente con tu arsenal... �Volver�s!");
						break;
						
					default: 
						System.out.println("No es la respuesta que esper�bamos...");
						res = null;
						break;
				}
			
			} while(res == null);
		}
	}
	
	
	/**
	 * This function gets the result from a battle
	 * @author Raquel Malo. Pasada a recursiva por Sonia Pujol
	 * @param Enemigo enemigo It needs the found enemy to fight
	 * @param Protagonista protagonista It needs a main character to interact
	 * @param boolean partida It needs a boolean to continue or not the game play
	 */
	public static boolean luchaEntrePersonajes(Enemigo enemigo, Protagonista protagonista, boolean partida, Celda celdaActual) {
		
		System.out.println("Enemigo a la vista: "+enemigo);
		ArrayList<Arma> armasUsadas = protagonista.elegirArmas();
		protagonista.setAtaqueActual(armasUsadas);
		protagonista.setDefensaActual(armasUsadas);
		System.out.println("�Que comience la batalla!");
		byte resultadoCombate = protagonista.combate(enemigo);

		switch (resultadoCombate) {
			case 0:
				System.out.println("Se ha saldado con un empate y los dos sobreviv�s...");
				System.out.println("�Cuidado, que ataca de nuevo!");
				luchaEntrePersonajes(enemigo, protagonista, partida, celdaActual);
				break;
			case 1:
				System.out.println("Perdiste. Acabas de morir a manos de tu enemigo.");
				partida = false;
				break;
			case 2:
				if (enemigo.getTipoEnemigo()==TipoEnemigo.COMUN) {
					System.out.println("Ganaste. Un enemigo menos.");
					//DELETE ELEMENT FROM CELDA
					celdaActual.setElemento(null);	
					partida = true;
				} else {//Only BOSS is possible
					System.out.println("Enhorabuena! Has ganado la partida.");
					partida = false;
				}
				break;
			case 3:
				System.out.println("Se ha saldado con un empate y los dos estais muertos.");
				partida = false;
				break;
			default:
				System.out.println("Resultado invalido del combate. Error del programa.");
				break;
			}
		
		return partida;
		}

	/**
		 * Function to collect money bag. Add the bags to the protagonist who passes through a random cell
		 * @author Grupo 4 Leidy
		 * @version 1.0
	 */	

	public static void recogerBolsa(BolsaDinero bolsaDinero, Protagonista protagonista, Celda celdaActual) {
		byte sumaMonedas = (byte)(bolsaDinero.getSaldo() + protagonista.getSaldo());//aseguro que el resultado es un byte
		
		protagonista.setSaldo(sumaMonedas);
		celdaActual.setElemento(null);//The cell is updated and is empty			
		System.out.println(bolsaDinero.toString());
		System.out.println("Tienes ahora "+ sumaMonedas +" monedas!");
	}
}