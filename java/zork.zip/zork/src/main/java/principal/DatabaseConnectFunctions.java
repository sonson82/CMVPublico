package principal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


/**
 * This class contains the functions needed to connect with database
 * @author Sonia Pujol
 * @version 1.0
 */
public class DatabaseConnectFunctions {
	
	
	/**
	 * This function sets elements to database.
	 */
	public static void setToDatabase (String nombre, java.sql.Timestamp hora_inicio, int cambios_casilla) {	
		try {		
			//Conectar
			Connection conexion = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/zork", "zork", "zork");
	
			//operar 
			Statement smt = conexion.createStatement();
			smt.executeUpdate("insert into partida (nombre, hora_inicio, cambios_casilla) values ('" + nombre + "', '" + hora_inicio + "', '" + cambios_casilla + "') ");
			
			//Desconectar
			smt.close();
			conexion.close();
			
		} catch (SQLException e) {		
			e.printStackTrace();
		} 
		
	}
	
	
	
	/**
	 * This function gets elements from database and print them
	 */
	public static void getFromDatabase (String nombre) {	
		try {		
			//Conectar
			Connection conexion = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/zork", "zork", "zork");
	
			//operar 
			Statement smt = conexion.createStatement();
			ResultSet rs = smt.executeQuery("select nombre, hora_inicio, cambios_casilla FROM partida WHERE nombre = '" + nombre + "'");
			
			String result = "";
			
			if(rs.next()) {
				result += "Estos son los datos de tus partidas anteriores: " + "\n";				
				do{	  
					result += "-  Fecha y hora de inicio de partida: " + rs.getString("hora_inicio") + " hiciste un total de " + rs.getString("cambios_casilla") +" movimientos."+ "\n";
				}while (rs.next()); 
			} else {
				result += "Debe ser tu primera vez... �No tenemos datos tuyos guardados! "+ "\n";	
				
			}
			
			System.out.println(result);
			
		
			//Desconectar
			smt.close();
			conexion.close();
			
		} catch (SQLException e) {		
			e.printStackTrace();
		} 
		
	}

}
