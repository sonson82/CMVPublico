package excepciones;

@SuppressWarnings("serial")
public class NullNameException extends Exception {

	public NullNameException(String message) {
		super(message);
	}
	
}
