package excepciones;

/**
 * This exception throws in case of player is positioned off the map
 * @author S�nia Pujol
 *
 */
@SuppressWarnings("serial")
public class OffMapPositionException extends Exception{
	public OffMapPositionException(String msg) {
		super(msg);
	}
}
