package excepciones;

@SuppressWarnings("serial")
public class NullLetraException extends Exception {

	public NullLetraException (String message) {
		super(message);
	}

}


 
	

