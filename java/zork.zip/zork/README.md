# Grupo4-cmv-accenture
Grupo de trabajo para el curso CMV-Accenture
